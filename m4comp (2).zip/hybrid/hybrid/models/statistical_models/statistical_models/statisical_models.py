import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import adfuller
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from sklearn.metrics import mean_squared_error
from itertools import product
import statsmodels.api as sm 
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from error_metrics import smape, mase
from tabulate import tabulate


df_train = pd.read_csv("Hourly_wdates.csv", parse_dates=True, index_col=0)
df_test = pd.read_csv("Hourly-test.csv", parse_dates=True, index_col=0)


# Ignore Warnings
import warnings
warnings.filterwarnings('ignore')

def arima(df_train, df_test, n):
    # Data Preparation
    df = df_train.iloc[n - 1, 2:].dropna()
    df = df[df > 0]
    df = pd.to_numeric(df, errors="coerce")

    initial_date = df_train.iloc[n - 1, 0]
    index = pd.date_range(start=initial_date, periods=len(df), freq="H")
    df.index = index

    tested = df_test.iloc[n - 1, 1:].dropna()
    tested = tested[tested > 0]
    tested = pd.to_numeric(tested, errors="coerce")

    last_date_train = df.index[-1]
    index_test = pd.date_range(start=last_date_train, periods=len(tested), freq="H")
    tested.index = index_test

    # Data Splitting
    split_index = int(len(df) * 0.90)
    train_df = df.iloc[:split_index]
    val_df = df.iloc[split_index:]

    # Make series stationary
    row_series = pd.Series(df)
    differenced_data = row_series.diff().dropna()

    # ARIMA Modeling
    arima_model = ARIMA(train_df, order=(2, 1, 5))
    arima_results = arima_model.fit()

    # Make predictions for validation period
    start_index = val_df.index[0]
    end_index = val_df.index[-1]
    predictions = arima_results.predict(start=start_index, end=end_index, typ='levels')



    # Plot actual vs. predicted values
    plt.figure(figsize=(12, 6))
    plt.plot(val_df.index, val_df, label='Actual', color='blue')
    plt.plot(predictions.index, predictions, label='Predicted', color='red')
    plt.xlabel('Time')
    plt.ylabel('Value')
    plt.title('Actual vs. Predicted Values (Validation Period) ARIMA')
    plt.legend()
    plt.show()

    # Calculate sMAPE and MASE
    smape_value = round(smape(val_df, predictions), 2)
    mase_value = round(mase(train_df, val_df, predictions[:-2], 24), 2)

    # Table of comparison
    table = [["Symmetric mean absolute percentage error (sMAPE)", f"{smape_value} %"],
             ["Mean Absolute Scaled Error (MASE)", mase_value]]

    # Print table
    print(tabulate(table, headers=["Metric", "Value"], tablefmt="simple"))



def bats(df_train, df_test, n):
    ### Data Preparation ###
    df = df_train.iloc[n - 1, 2:].dropna()
    df = df[df > 0]
    df = pd.to_numeric(df, errors="coerce")

    initial_date = df_train.iloc[n - 1, 0]
    index = pd.date_range(start=initial_date, periods=len(df), freq="H")
    df.index = index

    tested = df_test.iloc[n - 1, 1:].dropna()
    tested = tested[tested > 0]
    tested = pd.to_numeric(tested, errors="coerce")

    last_date_train = df.index[-1]
    index_test = pd.date_range(start=last_date_train, periods=len(tested), freq="H")
    tested.index = index_test

    ### Data Splitting ###
    split_index = int(len(df) * 0.90)
    train_df = df.iloc[:split_index]
    val_df = df.iloc[split_index:]

    ### BATS Modeling ###
    bats_model = ExponentialSmoothing(train_df, trend='add', damped_trend=True, seasonal='add', seasonal_periods=24)
    bats_results = bats_model.fit()

    # Make predictions for validation period
    predictions = bats_results.predict(start=val_df.index[0], end=val_df.index[-1])

    # Plot actual vs. predicted values
    plt.figure(figsize=(12, 6))
    plt.plot(val_df.index, val_df, label='Actual', color='blue')
    plt.plot(predictions.index, predictions, label='Predicted', color='red')
    plt.xlabel('Time')
    plt.ylabel('Value')
    plt.title('Actual vs. Predicted Values (Validation Period) BATS')
    plt.legend()
    plt.show()

    # Calculate sMAPE and MASE
    smape_value = round(smape(val_df, predictions), 2)
    mase_value = round(mase(train_df, val_df, predictions[:-2], 24), 2)

    # Table of comparison
    table = [["Symmetric mean absolute percentage error (sMAPE)", f"{smape_value} %"],
             ["Mean Absolute Scaled Error (MASE)", mase_value]]

    # Print table
    print(tabulate(table, headers=["Metric", "Value"], tablefmt="simple"))



def sarimax(df_train, df_test, n):
    # Dropping NA values and using only positive values
    df = df_train.iloc[n - 1, 2:].dropna() 
    df = df[df > 0]
    df = pd.to_numeric(df, errors="coerce")

    # use initial value and set it to the first observation 
    initial_date = df_train.iloc[n - 1, 0]
    index = pd.date_range(start=initial_date, periods=len(df), freq="H")
    df.index = index 

    # Doing the same for tested values, just using the last date of the trained set 
    tested = df_test.iloc[n - 1, 1:].dropna()
    tested = tested[tested > 0]
    tested = pd.to_numeric(tested, errors="coerce")

    last_date_train = df.index[-1]
    index_test = pd.date_range(start=last_date_train, periods=len(tested), freq="H")
    tested.index = index_test

    # Splitting into training and validation sets 
    split_index = int(len(df) * 0.90)
    train_df = df.iloc[: split_index]
    val_df = df.iloc[split_index :]

    # Fit the SARIMAX model
    sarimax_model = SARIMAX(train_df, order=(2, 1, 4), seasonal_order=(1, 0, 1, 24))
    sarimax_results = sarimax_model.fit()

    # Make predictions for the validation period
    start_index = val_df.index[0]
    end_index = val_df.index[-1]
    predictions = sarimax_results.predict(start=start_index, end=end_index, typ='levels')

    # Plot actual vs. predicted values
    plt.figure(figsize=(12, 6))
    plt.plot(val_df.index, val_df, label='Actual', color='blue')
    plt.plot(predictions.index, predictions, label='Predicted', color='red')
    plt.xlabel('Time')
    plt.ylabel('Value')
    plt.title('Actual vs. Predicted Values (Validation Period) SARIMAX')
    plt.legend()
    plt.show()

    # Calculating sMAPE and MASE
    smape_value = round(smape(val_df, predictions), 2)
    mase_value = round(mase(train_df, val_df, predictions[:-2], 24), 2)

    # Table of comparison
    table = [["Symmetric mean absolute percentage error (sMAPE)", f"{smape_value} %"],
             ["Mean Absolute Scaled Error (MASE)", mase_value]]

    # Print table
    print(tabulate(table, headers=["Metric", "Value"], tablefmt="simple"))


arima(df_train, df_test, 1)
print("====================================================================")
bats(df_train, df_test, 1)
print("====================================================================")
sarimax(df_train, df_test, 1)
