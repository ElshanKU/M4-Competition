import numpy as np
import pandas as pd


def smape(a, b):
    """
    Calculates sMAPE

    :param a: actual values
    :param b: predicted values
    :return: sMAPE (clipped between 0% and 100%)
    """
    a = np.asarray(a)
    b = np.asarray(b)
    smape_value = np.mean(2.0 * np.abs(a - b) / (np.abs(a) + np.abs(b))).item()
    
    # Clip sMAPE values to ensure they are within the range of 0% to 100%
    smape_value = max(0, min(smape_value, 1)) * 100
    
    return smape_value

def mase(insample, y_test, y_hat_test, freq):
    """
    Calculates MAsE
    
    :param insample: insample data
    :param y_test: out of sample target values
    :param y_hat_test: predicted values
    :param freq: data frequency
    :return:
    """
    y_hat_naive = []
    for i in range(freq, len(insample)):
        y_hat_naive.append(insample[i - freq])

    masep = np.mean(np.abs(np.array(insample[freq:]) - np.array(y_hat_naive)))

    #print(mean_abs_error)
    #print(masep)

    return np.mean(np.abs(y_test - y_hat_test)) / masep




def moving_averages(ts_init, window):
    """
    Calculates the moving averages for a given TS

    :param ts_init: the original time series
    :param window: window length
    :return: moving averages ts
    """
    """
    As noted by Professor Isidro Lloret Galiana:
    line 82:
    if len(ts_init) % 2 == 0:
    
    should be changed to
    if window % 2 == 0:
    
    This change has a minor (less then 0.05%) impact on the calculations of the seasonal indices
    In order for the results to be fully replicable this change is not incorporated into the code below
    """
    
    if len(ts_init) % 2 == 0:
        ts_ma = pd.rolling_mean(ts_init, window, center=True)
        ts_ma = pd.rolling_mean(ts_ma, 2, center=True)
        ts_ma = np.roll(ts_ma, -1)
    else:
        ts_ma = pd.rolling_mean(ts_init, window, center=True)

    return ts_ma