from darts import TimeSeries
from darts.models import NBEATSModel, TransformerModel
from error_metrics import smape, mase 
import pandas as pd
import numpy as np
from tabulate import tabulate
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from sklearn.metrics import r2_score

df_train = pd.read_csv("Hourly_wdates.csv", parse_dates=True, index_col=0)
df_test = pd.read_csv("Hourly-test.csv", parse_dates=True, index_col=0)

def nbeats_model(df_train, df_test, n, horizons):
    df = df_train.iloc[n - 1, 2:].dropna()
    df = df[df > 0].astype(float)
    initial_date = df_train.iloc[n - 1, 0]
    df.index = pd.date_range(start=initial_date, periods=len(df), freq='H')

    tested = df_test.iloc[n - 1, 1:].dropna()
    tested = tested[tested > 0].astype(float)
    last_date_train = df.index[-1]
    index_test = pd.date_range(start=last_date_train + pd.Timedelta(hours=1), periods=len(tested), freq='H')
    tested.index = index_test

    validation_size = horizons
    train_series = df.iloc[:-validation_size]
    val_series = df.iloc[-validation_size:]

    train_series_ts = TimeSeries.from_series(train_series)
    val_series_ts = TimeSeries.from_series(val_series)
    test_series_ts = TimeSeries.from_series(tested)

    # NBEATS Model
    nbeats_model = NBEATSModel(
        input_chunk_length=24,
        output_chunk_length=24,
        n_epochs=15,
        num_stacks=3,
        num_blocks=3,
        num_layers=3,
        dropout=0.1,
        layer_widths=512,
        batch_size=32,
        random_state=42
    )

    nbeats_model.fit(train_series_ts, val_series=val_series_ts)

    predictions = nbeats_model.predict(n=len(tested)).values().flatten()

    smape_value = round(smape(tested.values, predictions), 2)
    mase_value = round(mase(df.values, tested.values, predictions, 24), 2)

    #table = [["Symmetric mean absolute percentage error (sMAPE)", f"{smape_value} %"],
    #         ["Mean Absolute Scaled Error (MASE)", mase_value]]

    return predictions

# Usage example
#predictions, metrics_table = nbeats_model(df_train, df_test, 1, 48)
#print(tabulate(metrics_table, headers=["Metric", "Value"], tablefmt="simple"))

def timegpt_model(df_train, df_test, n, horizons):
    df = df_train.iloc[n - 1, 2:].dropna()
    df = df[df > 0].astype(float)
    initial_date = df_train.iloc[n - 1, 0]
    df.index = pd.date_range(start=initial_date, periods=len(df), freq='H')

    tested = df_test.iloc[n - 1, 1:].dropna()
    tested = tested[tested > 0].astype(float)
    last_date_train = df.index[-1]
    index_test = pd.date_range(start=last_date_train + pd.Timedelta(hours=1), periods=len(tested), freq='H')
    tested.index = index_test

    validation_size = horizons
    train_series = df.iloc[:-validation_size]
    val_series = df.iloc[-validation_size:]

    train_series_ts = TimeSeries.from_series(train_series)
    val_series_ts = TimeSeries.from_series(val_series)
    test_series_ts = TimeSeries.from_series(tested)

    transformer_model = TransformerModel(
        input_chunk_length=24,
        output_chunk_length=24,
        n_epochs=15,
        d_model=64,
        nhead=4,
        num_encoder_layers=3,
        num_decoder_layers=3,
        dropout=0.1,
        activation="relu",
        batch_size=32,
        random_state=42
    )

    transformer_model.fit(train_series_ts, val_series=val_series_ts)

    predictions = transformer_model.predict(n=len(tested)).values().flatten()

    smape_value = round(smape(tested.values, predictions), 2)
    mase_value = round(mase(df.values, tested.values, predictions, 24), 2)

    #table = [["Symmetric mean absolute percentage error (sMAPE)", f"{smape_value} %"],
    #         ["Mean Absolute Scaled Error (MASE)", mase_value]]

    return predictions

# Usage example
#predictions, metrics_table = timegpt_model(df_train, df_test, 1, 48)
#print(tabulate(metrics_table, headers=["Metric", "Value"], tablefmt="simple"))

def lstm_model(df_train, df_test, n, horizons):
    # Data Preparation
    df = df_train.iloc[n - 1, 2:].dropna()
    df = df[df > 0].astype(float)
    initial_date = df_train.iloc[n - 1, 0]
    df.index = pd.date_range(start=initial_date, periods=len(df), freq='H')

    tested = df_test.iloc[n - 1, 1:].dropna()
    tested = tested[tested > 0].astype(float)
    last_date_train = df.index[-1]
    index_test = pd.date_range(start=last_date_train + pd.Timedelta(hours=1), periods=len(tested), freq='H')
    tested.index = index_test

    split_index = int(len(df) * 0.90)  # 90% for training, 10% for validation
    train_data = df.iloc[:split_index]
    val_data = df.iloc[split_index:]

    def create_sequences(data, seq_length):
        X, y = [], []
        for i in range(len(data) - seq_length):
            X.append(data[i:i + seq_length])
            y.append(data[i + seq_length])
        return np.array(X), np.array(y)

    seq_length = 24  # Sequence length for each input (hours in a day)
    X_train, y_train = create_sequences(train_data.values, seq_length)
    X_val, y_val = create_sequences(val_data.values, seq_length)

    model = Sequential([
        LSTM(50, activation='relu', input_shape=(seq_length, 1)),
        Dense(1)
    ])

    model.compile(optimizer='adam', loss='mse')

    model.fit(X_train, y_train, epochs=30, batch_size=32, validation_data=(X_val, y_val), verbose=1)

    forecast = []
    current_batch = train_data.iloc[-seq_length:].values.reshape((1, seq_length, 1))

    for i in range(len(val_data)):
        current_pred = model.predict(current_batch)[0]
        forecast.append(current_pred)
        current_batch = np.append(current_batch[:, 1:, :], [[current_pred]], axis=1)

    forecast = np.array(forecast).flatten()
    actual_data = val_data.values.flatten()

    smape_value = round(smape(actual_data, forecast), 2)
    mase_value = round(mase(train_data.values, actual_data, forecast, 24), 2)

    #table = [["Symmetric mean absolute percentage error (sMAPE)", f"{smape_value} %"],
    #         ["Mean Absolute Scaled Error (MASE)", mase_value]]

    return forecast

# Usage example
#predictions, metrics_table = lstm_model(df_train, df_test, 1, 48)
#print(tabulate(metrics_table, headers=["Metric", "Value"], tablefmt="simple"))

