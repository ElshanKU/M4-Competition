import pandas as pd
import matplotlib.pyplot as plt

# Read the CSV file
df = pd.read_csv("model_evaluation_metrics.csv")

# Calculate averages
avg_smape = df['SMAPE'].mean()
avg_mase = df['MASE'].mean()

# Plot SMAPE with average line
plt.figure(figsize=(10, 5))
plt.plot(df['n'], df['SMAPE'], marker='o', color='blue', label='SMAPE')
plt.axhline(y=avg_smape, color='red', linestyle='--', label='Average SMAPE')
plt.xlabel('n')
plt.ylabel('SMAPE')
plt.title('SMAPE vs n')
plt.legend()
plt.grid(True)
plt.savefig('SMAPE_plot.png')
plt.show()

# Plot MASE with average line
plt.figure(figsize=(10, 5))
plt.plot(df['n'], df['MASE'], marker='o', color='green', label='MASE')
plt.axhline(y=avg_mase, color='red', linestyle='--', label='Average MASE')
plt.xlabel('n')
plt.ylabel('MASE')
plt.title('MASE vs n')
plt.legend()
plt.grid(True)
plt.savefig('MASE_plot.png')
plt.show()

# Print average values
print("Average SMAPE:", avg_smape)
print("Average MASE:", avg_mase)
